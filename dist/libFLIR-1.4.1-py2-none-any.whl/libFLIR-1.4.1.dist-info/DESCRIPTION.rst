FLIR TAU Control Library


